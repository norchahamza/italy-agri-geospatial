# Geospatial analytics of Italy's agricultural transformation (2006-2024)
_Auto-generated draft - mode: **real**. Edit and complete the interpretation._

## 1. Where did crops relocate? (shift-share regional effect, hectares)
**Largest gains**
| province_code | crop | e0 | e1 | regional_effect |
|---|---|---|---|---|
| ITF47 | wheat | 295,293.00 | 300,500.00 | 50,710.72 |
| ITG12 | wheat | 80,000.00 | 91,516.67 | 23,844.41 |
| ITG14 | grapes | 27,299.33 | 43,001.33 | 17,389.15 |
| ITH34 | grapes | 28,195.33 | 43,098.67 | 16,645.86 |
| ITH56 | wheat | 49,966.67 | 57,941.67 | 15,674.70 |
| ITC11 | maize | 64,433.33 | 47,138.00 | 15,315.15 |
| ITH37 | wheat | 27,195.00 | 37,177.67 | 14,173.33 |
| ITC16 | maize | 50,560.00 | 37,812.67 | 12,841.69 |
| ITH36 | wheat | 15,956.00 | 25,485.00 | 11,987.77 |
| ITF47 | olives | 184,500.00 | 187,650.00 | 11,511.76 |

**Largest losses**
| province_code | crop | e0 | e1 | regional_effect |
|---|---|---|---|---|
| ITG2 | wheat | 76,413.00 | 24,823.00 | -39,815.00 |
| ITF45 | olives | 90,482.67 | 65,483.33 | -20,898.55 |
| ITI21 | sunflower | 35,866.67 | 11,333.33 | -20,630.94 |
| ITI21 | wheat | 64,192.00 | 38,566.67 | -15,733.55 |
| ITI19 | wheat | 49,913.00 | 26,741.33 | -15,480.23 |
| ITG14 | wheat | 40,916.67 | 22,013.33 | -12,598.20 |
| ITF47 | grapes | 83,533.33 | 67,543.00 | -10,827.81 |
| ITF43 | wheat | 28,798.33 | 13,800.00 | -10,560.60 |
| ITH41 | maize | 42,500.00 | 10,458.33 | -10,531.91 |
| ITF52 | wheat | 75,709.00 | 54,248.00 | -9,794.48 |

## 2. Trends (Mann-Kendall, area)
Series by trend: {'decreasing': 255, 'no_trend': 193, 'increasing': 116}
**Strongest growth (% / year)**
| province_code | crop | sen_slope_pct_per_year | p |
|---|---|---|---|
| ITH35 | olives | 25.84 | 0.00 |
| ITC44 | olives | 17.65 | 0.00 |
| ITC49 | sunflower | 14.54 | 0.00 |
| ITH36 | sunflower | 14.08 | 0.00 |
| ITH43 | sunflower | 13.14 | 0.01 |
| ITH52 | sunflower | 12.20 | 0.00 |
| ITH54 | sunflower | 11.77 | 0.00 |
| ITC48 | sunflower | 11.53 | 0.00 |
| ITC13 | olives | 11.32 | 0.00 |
| ITH32 | sunflower | 11.01 | 0.00 |

## 3. Spatial clusters (Local Moran's I)
lisa_cluster  High-High  High-Low  Low-High  Low-Low  Not significant
year                                                                 
2006                 78         2        28      155              529
2024                 82         3        27      201              479

## 6. Limitations
- FAOSTAT is national only; environmental links are trend-level, not province-level.
- Province boundaries changed during the period; reformed provinces were merged into stable units: Milano + Monza e Brianza; Ascoli Piceno + Fermo; Foggia + Bari + Barletta-Andria-Trani; Sardegna (all provinces) (config/sources.yml, config/province_crosswalk.csv).
- Correlation with climate is not causation; technology, prices and policy are not modelled here.

## 7. Strategic insights (to write)
- Policymakers: ...
- Agribusiness: ...
- Investors: ...